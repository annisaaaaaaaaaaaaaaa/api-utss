<?php

namespace Database\Seeders;

use App\Models\Contact;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ContactSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        $numberOfContacts = 50;

        // Retrieve all user IDs to associate contacts with users
        $userIds = User::pluck('id')->toArray();

        // Seed contacts
        for ($i = 0; $i < $numberOfContacts; $i++) {
            $contactData = [
                'first_name' => 'John', // Example first name
                'last_name' => 'Doe', // Example last name
                'email' => 'john.doe@example.com', // Example email
                'phone' => '123456789', // Example phone number
                'user_id' => $userIds[array_rand($userIds)], // Randomly assign a user ID
            ];

            // Create a new contact with the generated data
            Contact::create($contactData);
        }
    }
}
