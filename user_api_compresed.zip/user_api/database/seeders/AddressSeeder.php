<?php

namespace Database\Seeders;

use App\Models\Address;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Faker\Factory as Faker;


class AddressSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //

        $faker = Faker::create();




        $numberOfAddresses = 10;

        for ($i = 0; $i < $numberOfAddresses; $i++) {
            Address::create([
                'street' => $faker->streetAddress,
                'city' => $faker->city,
                'province' => $faker->state,
                'country' => $faker->country,
                'postal_code' => $faker->postcode,
                'contacts' => rand(1, 3) // Assuming contact IDs range from 1 to 100
            ]);
        }
    }
}
