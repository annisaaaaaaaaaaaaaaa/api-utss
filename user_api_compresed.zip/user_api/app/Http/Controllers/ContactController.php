<?php

namespace App\Http\Controllers;

use App\Http\Requests\AddContactRequest;
use App\Http\Requests\UpdateContactRequest;
use App\Models\Contact;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ContactController extends Controller
{
    //


    public function search(Request $request)
    {

        $name = $request->query('name');
        $phone = $request->query('phone');
        $email = $request->query('email');
        $size = $request->input('size', 10);
        $page = $request->input('page', 1); // Default page is 1

        // Extracted user ID from the middleware
        $userId = Auth::user()->id;


        $contacts = Contact::where('user_id', $userId)
            ->where(function ($queryBuilder) use ($name, $phone, $email) {
                $queryBuilder->where('first_name', 'like', "%" . $name . "%")
                    ->orWhere('phone', $phone)->orWhere('email', $email);
            })
            ->paginate($size, ['*'], 'page', $page);

        return response()->json([
            'data' => $contacts->items(),
            'errors' => null,
            'meta' => [
                'current_page' => $contacts->currentPage(),
                'last_page' => $contacts->lastPage()
            ]
        ]);
    }

    public function add(AddContactRequest $addContactRequest)
    {
        $data = $addContactRequest->validated();

        $userId = Auth::user()->id;

        $contact = Contact::create(
            [
                'user_id' => $userId,
                'first_name' => $data['first_name'],
                'last_name' => $data['last_name'],
                'email' => $data['email'],
                'phone' => $data['phone']
            ]
        );
        return response()->json(
            [
                'data' => $contact,
                'errors' => null
            ],
            201
        );
    }

    public function get($id)
    {

        $userId = Auth::user()->id;

        // Find the contact by ID and user ID
        $contact = Contact::where('id', $id)
            ->where('user_id', $userId)
            ->firstOrFail();

        return response()->json([
            'data' => $contact,
            'errors' => null,
        ]);

    }
}

