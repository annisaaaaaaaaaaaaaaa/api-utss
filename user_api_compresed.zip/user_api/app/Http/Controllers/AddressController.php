<?php

namespace App\Http\Controllers;

use App\Http\Requests\AddAddressRequest;
use App\Http\Requests\UpdateAddressRequest;
use App\Models\Address;
use App\Models\Contact;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Request;

class AddressController extends Controller
{
    //

    public function findByContact($contactId)
    {

        $contact = Contact::where('id', $contactId)->first();
        if (!isset($contact)) {
            throw new HttpResponseException(response([
                'errors' => [
                    'contact not found'
                ]
            ]));
        }

        $address = Address::where('contacts', $contactId)->get();
        return response()->json(
            ['data' => $address],
            200
        );

    }

    public function add(AddAddressRequest $request, $contactId)
    {
        $data = $request->validated();

        $contact = Contact::where('id', $contactId)->first();
        if (!isset($contact)) {
            throw new HttpResponseException(response([
                'errors' => [
                    'contact not found'
                ]
            ]));
        }

        $data['contacts'] = $contactId;
        $address = Address::create($data);
        return response()->json([
            $address
        ], 201);
    }

    public function get($contactId, $addressId)
    {

        $contact = Contact::where('id', $contactId)->first();
        if (!isset($contact)) {
            throw new HttpResponseException(response([
                'errors' => [
                    'contact not found'
                ]
            ]));
        }

        $contact = Address::where('contacts', $contactId)->where('id', $addressId)->first();
        return response()->json([
            'data' => $contact
        ], 200);
    }

    public function update(UpdateAddressRequest $request, $contactId, $addressId)
    {
        $data = $request->validated();
        $contact = Contact::where('id', $contactId)->first();
        if (!isset($contact)) {
            throw new HttpResponseException(response([
                'errors' => [
                    'contact not found'
                ]
            ]));
        }

        $contact = Address::where('contacts', $contactId)->where('id', $addressId)->first();

        $contact->street = $data['street'];
        $contact->province = $data['province'];
        $contact->postal_code = $data['postal_code'];
        $contact->country = $data['country'];
        $contact->city = $data['city'];
        $contact->save();
        return response()->json($contact->refresh());
    }

    public function delete($contactId, $addressId)
    {

        $contact = Contact::where('id', $contactId)->first();
        if (!isset($contact)) {
            throw new HttpResponseException(response([
                'errors' => [
                    'contact not found'
                ]
            ]));
        }

        $contact = Address::where('contacts', $contactId)->where('id', $addressId)->first();
        if (!isset($contact)) {
            throw new HttpResponseException(response([
                'errors' => [
                    'address not found'
                ]
            ]));
        }

        $contact->delete();
        return response()->json(
            [
                'data' => true,
                'errors' => null
            ]
        );

    }

}
