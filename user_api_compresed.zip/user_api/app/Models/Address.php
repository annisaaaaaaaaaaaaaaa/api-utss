<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Address extends Model
{
    use HasFactory;

    protected $table = 'address';

    protected $fillable = [
        'id',
        'street',
        'city',
        'province',
        'country',
        'postal_code',
        'contacts'
    ];

    public function contact()
    {
        return $this->belongsTo(Contact::class, "contacts");
    }
}
